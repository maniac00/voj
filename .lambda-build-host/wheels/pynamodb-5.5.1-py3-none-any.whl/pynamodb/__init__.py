"""
PynamoDB Library
^^^^^^^^^^^^^^^^

A simple abstraction over DynamoDB

"""
__author__ = 'Jharrod LaFon'
__license__ = 'MIT'
__version__ = '5.5.1'
